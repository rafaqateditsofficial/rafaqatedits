/* RAFAQAT EDITS — website interactions */
document.addEventListener("DOMContentLoaded", function () {
  // Mobile menu / open window
  const menuToggle = document.getElementById("menuToggle");
  const siteNav = document.getElementById("siteNav");

  if (menuToggle && siteNav) {
    menuToggle.addEventListener("click", function () {
      siteNav.classList.toggle("open");
      menuToggle.setAttribute(
        "aria-expanded",
        siteNav.classList.contains("open") ? "true" : "false"
      );
    });

    siteNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        siteNav.classList.remove("open");
      });
    });
  }

  // FAQ accordion
  document.querySelectorAll(".faq button").forEach(function (button) {
    button.addEventListener("click", function () {
      const item = button.parentElement;
      item.classList.toggle("open");
    });
  });

  // Hero changing headline
  const heroRotator = document.getElementById("heroRotator");
  if (heroRotator) {
    const words = [
      "YOUR IMPACT.",
      "YOUR STORY.",
      "YOUR BRAND.",
      "YOUR MOMENT."
    ];
    let index = 0;

    setInterval(function () {
      heroRotator.style.opacity = "0";
      heroRotator.style.transform = "translateY(10px)";

      setTimeout(function () {
        index = (index + 1) % words.length;
        heroRotator.textContent = words[index];
        heroRotator.style.opacity = "1";
        heroRotator.style.transform = "translateY(0)";
      }, 180);
    }, 2400);
  }

  // Scroll reveal
  function revealElements() {
    document.querySelectorAll(".reveal").forEach(function (element) {
      const box = element.getBoundingClientRect();
      if (box.top < window.innerHeight * 0.92) {
        element.classList.add("visible");
      }
    });
  }

  revealElements();
  window.addEventListener("scroll", revealElements, { passive: true });

  // Animated counters
  document.querySelectorAll("[data-target]").forEach(function (element) {
    const target = Number(element.dataset.target || 0);
    let started = false;

    function startCounter() {
      if (started) return;

      const box = element.getBoundingClientRect();
      if (box.top < window.innerHeight * 0.9) {
        started = true;
        let value = 0;
        const step = Math.max(1, Math.ceil(target / 35));

        const timer = setInterval(function () {
          value = Math.min(target, value + step);
          element.textContent = value;

          if (value >= target) {
            clearInterval(timer);
          }
        }, 28);
      }
    }

    startCounter();
    window.addEventListener("scroll", startCounter, { passive: true });
  });

  // Free Trial modal
  const trialModal = document.getElementById("trialModal");

  document.querySelectorAll(".open-trial").forEach(function (button) {
    button.addEventListener("click", function () {
      if (trialModal) {
        trialModal.classList.add("open");
      }
    });
  });

  document.querySelectorAll(".trial-close").forEach(function (button) {
    button.addEventListener("click", function () {
      if (trialModal) {
        trialModal.classList.remove("open");
      }
    });
  });

  if (trialModal) {
    trialModal.addEventListener("click", function (event) {
      if (event.target === trialModal) {
        trialModal.classList.remove("open");
      }
    });
  }

  // Free Trial → WhatsApp
  const trialForm = document.getElementById("trialForm");

  if (trialForm) {
    trialForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const data = new FormData(trialForm);

      const message = [
        "RAFAQAT EDITS — Free Trial Request",
        "Name: " + (data.get("name") || ""),
        "WhatsApp: " + (data.get("whatsapp") || ""),
        "Project: " + (data.get("projectType") || ""),
        "Video: " + (data.get("videoLink") || ""),
        "Message: " + (data.get("message") || "")
      ].join("\n");

      window.open(
        "https://wa.me/923106210016?text=" +
          encodeURIComponent(message),
        "_blank"
      );

      if (trialModal) {
        trialModal.classList.remove("open");
      }
    });
  }

  // Portfolio video popup
  const videoModal = document.getElementById("videoModal");
  const videoFrame = document.getElementById("videoFrame");

  document.querySelectorAll("[data-video]").forEach(function (card) {
    card.addEventListener("click", function () {
      const videoId = card.getAttribute("data-video");

      if (!videoModal || !videoFrame || !videoId || videoId === "VIDEO_ID_HERE") {
        return;
      }

      videoFrame.src =
        "https://www.youtube.com/embed/" +
        encodeURIComponent(videoId) +
        "?autoplay=1";

      videoModal.classList.add("open");
    });
  });

  document.querySelectorAll(".video-close").forEach(function (button) {
    button.addEventListener("click", function () {
      if (videoModal) {
        videoModal.classList.remove("open");
      }

      if (videoFrame) {
        videoFrame.src = "";
      }
    });
  });

  if (videoModal) {
    videoModal.addEventListener("click", function (event) {
      if (event.target === videoModal) {
        videoModal.classList.remove("open");
        if (videoFrame) videoFrame.src = "";
      }
    });
  }
});
