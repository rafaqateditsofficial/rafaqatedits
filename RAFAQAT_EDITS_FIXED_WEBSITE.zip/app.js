/* RAFAQAT EDITS — repaired interactions; no Firebase or login added */
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    } else {
      fn();
    }
  }

  ready(function () {
    /* Enable reveal animation only after JS has loaded.
       CSS keeps all .reveal content visible when JS is unavailable. */
    document.body.classList.add("js-ready");

    var menu = document.getElementById("menuToggle");
    var nav = document.getElementById("siteNav");

    if (menu && nav) {
      menu.addEventListener("click", function () {
        var open = nav.classList.toggle("open");
        menu.setAttribute("aria-expanded", open ? "true" : "false");
      });

      nav.querySelectorAll("a").forEach(function (link) {
        link.addEventListener("click", function () {
          nav.classList.remove("open");
          menu.setAttribute("aria-expanded", "false");
        });
      });
    }

    /* FAQ */
    document.querySelectorAll(".faq button").forEach(function (button) {
      button.addEventListener("click", function () {
        button.parentElement.classList.toggle("open");
      });
    });

    /* Changing hero text */
    var rotator = document.getElementById("heroRotator");
    if (rotator) {
      var words = ["YOUR IMPACT.", "YOUR STORY.", "YOUR BRAND.", "YOUR MOMENT."];
      var index = 0;
      window.setInterval(function () {
        rotator.style.opacity = "0";
        rotator.style.transform = "translateY(8px)";
        window.setTimeout(function () {
          index = (index + 1) % words.length;
          rotator.textContent = words[index];
          rotator.style.opacity = "1";
          rotator.style.transform = "translateY(0)";
        }, 180);
      }, 2400);
    }

    /* Scroll reveal */
    function reveal() {
      document.querySelectorAll(".reveal").forEach(function (el) {
        var box = el.getBoundingClientRect();
        if (box.top < window.innerHeight * 0.92) {
          el.classList.add("visible");
        }
      });
    }
    reveal();
    window.addEventListener("scroll", reveal, { passive: true });

    /* Counters */
    document.querySelectorAll("[data-target]").forEach(function (el) {
      var target = Number(el.getAttribute("data-target")) || 0;
      var started = false;

      function start() {
        if (started) return;
        if (el.getBoundingClientRect().top < window.innerHeight * 0.9) {
          started = true;
          var value = 0;
          var step = Math.max(1, Math.ceil(target / 35));
          var timer = window.setInterval(function () {
            value = Math.min(target, value + step);
            el.textContent = String(value);
            if (value >= target) window.clearInterval(timer);
          }, 28);
        }
      }

      start();
      window.addEventListener("scroll", start, { passive: true });
    });

    /* Free Trial modal */
    var trialModal = document.getElementById("trialModal");
    var trialForm = document.getElementById("trialForm");

    function openTrial() {
      if (!trialModal) return;
      trialModal.classList.add("open");
      trialModal.setAttribute("aria-hidden", "false");
      var name = document.getElementById("trialName");
      if (name) window.setTimeout(function () { name.focus(); }, 50);
    }

    function closeTrial() {
      if (!trialModal) return;
      trialModal.classList.remove("open");
      trialModal.setAttribute("aria-hidden", "true");
    }

    document.querySelectorAll(".open-trial").forEach(function (button) {
      button.addEventListener("click", openTrial);
    });
    document.querySelectorAll(".trial-close").forEach(function (button) {
      button.addEventListener("click", closeTrial);
    });

    if (trialModal) {
      trialModal.addEventListener("click", function (event) {
        if (event.target === trialModal) closeTrial();
      });
    }

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        closeTrial();
        var videoModal = document.getElementById("videoModal");
        if (videoModal) {
          videoModal.classList.remove("open");
          var frame = document.getElementById("videoFrame");
          if (frame) frame.src = "";
        }
      }
    });

    if (trialForm) {
      trialForm.addEventListener("submit", function (event) {
        event.preventDefault();
        var data = new FormData(trialForm);
        var message = [
          "RAFAQAT EDITS — Free Trial Request",
          "Name: " + (data.get("name") || ""),
          "WhatsApp: " + (data.get("whatsapp") || ""),
          "Project: " + (data.get("projectType") || ""),
          "Video: " + (data.get("videoLink") || ""),
          "Message: " + (data.get("message") || "")
        ].join("\n");

        window.open(
          "https://wa.me/923106210016?text=" + encodeURIComponent(message),
          "_blank",
          "noopener"
        );
        closeTrial();
      });
    }

    /* Portfolio video popup. Supports a real embed URL in data-video. */
    var videoModal = document.getElementById("videoModal");
    var videoFrame = document.getElementById("videoFrame");

    document.querySelectorAll(".video-open[data-video]").forEach(function (button) {
      button.addEventListener("click", function () {
        var url = button.getAttribute("data-video");
        if (!url || url.indexOf("VIDEO_ID_HERE") !== -1) {
          window.alert("Add a real YouTube embed URL to this portfolio item first.");
          return;
        }
        if (videoFrame) videoFrame.src = url;
        if (videoModal) videoModal.classList.add("open");
      });
    });

    document.querySelectorAll(".modal-close").forEach(function (button) {
      button.addEventListener("click", function () {
        if (videoModal) videoModal.classList.remove("open");
        if (videoFrame) videoFrame.src = "";
      });
    });

    if (videoModal) {
      videoModal.addEventListener("click", function (event) {
        if (event.target === videoModal) {
          videoModal.classList.remove("open");
          if (videoFrame) videoFrame.src = "";
        }
      });
    }
  });
})();
